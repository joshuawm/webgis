<template>

</template>

<script>
  export default {
    name: "makebox-choice.vue"
  }
</script>

<style scoped>

</style>
