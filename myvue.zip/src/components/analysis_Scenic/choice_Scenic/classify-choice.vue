<template>
    
</template>

<script>
    export default {
        name: "classify-choice",
        props:["choice"]
    }
</script>

<style scoped>

</style>
