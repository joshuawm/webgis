<template>
    
</template>

<script>
    export default {
        name: "distance-choice.vue"
    }
</script>

<style scoped>

</style>
