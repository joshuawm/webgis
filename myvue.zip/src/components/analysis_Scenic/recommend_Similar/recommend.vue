<template>
    
</template>

<script>
    export default {
        name: "recommend"
    }
</script>

<style scoped>

</style>
