<template>
    
</template>

<script>
    export default {
        name: "rating_analysis"
    }
</script>

<style scoped>

</style>
