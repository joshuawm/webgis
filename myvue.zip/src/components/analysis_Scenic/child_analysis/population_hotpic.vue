<template>
    
</template>

<script>
    export default {
        name: "population_hotpic"
    }
</script>

<style scoped>

</style>
