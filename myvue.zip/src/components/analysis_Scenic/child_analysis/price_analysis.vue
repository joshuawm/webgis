<template>
    
</template>

<script>
    export default {
        name: "price_analysis"
    }
</script>

<style scoped>

</style>
